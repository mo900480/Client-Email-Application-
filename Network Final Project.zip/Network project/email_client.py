import ssl, time, socket, imaplib, smtplib
from email import message_from_bytes
from email.header import decode_header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Email client using SMTP and IMAP protocols
class EmailClient:
    def __init__(self, smtp_host, smtp_port, imap_host, imap_port):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.imap_host = imap_host
        self.imap_port = imap_port

    def send_email(self, sender, password, receiver, subject, body):
        start = time.time()
        try:
            msg = MIMEMultipart()
            msg["From"] = sender
            msg["To"] = receiver
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain", "utf-8"))

            if self.smtp_port == 465:
                with smtplib.SMTP_SSL(self.smtp_host, self.smtp_port, context=ssl.create_default_context()) as s:
                    s.login(sender, password)
                    s.send_message(msg)
            else:
                with smtplib.SMTP(self.smtp_host, self.smtp_port) as s:
                    s.starttls(context=ssl.create_default_context())
                    s.login(sender, password)
                    s.send_message(msg)

            return True, time.time() - start, "Email sent successfully"
        except Exception as e:
            return False, time.time() - start, str(e)

    def receive_latest_email(self, email, password):
        start = time.time()
        try:
            with imaplib.IMAP4_SSL(self.imap_host, self.imap_port) as mail:
                mail.login(email, password)
                mail.select("INBOX")
                _, data = mail.search(None, "ALL")
                ids = data[0].split()
                if not ids:
                    return False, time.time() - start, None, None, "No emails found"

                _, msg_data = mail.fetch(ids[-1], "(RFC822)")
                msg = message_from_bytes(msg_data[0][1])

                subject = self._decode(msg["Subject"] or "")
                body = self._get_body(msg)
                return True, time.time() - start, subject, body, "Email received successfully"
        except Exception as e:
            return False, time.time() - start, None, None, str(e)

    def send_notification(self, text, host="127.0.0.1", port=9999):
        start = time.time()
        try:
            with socket.create_connection((host, port), timeout=5) as s:
                s.sendall(text.encode("utf-8"))
            return True, time.time() - start
        except Exception:
            return False, time.time() - start

    def _decode(self, value):
        parts = decode_header(value or "")
        return "".join(p.decode(e or "utf-8", "replace") if isinstance(p, bytes) else p for p, e in parts)

    def _get_body(self, msg):
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain" and "attachment" not in str(part.get("Content-Disposition", "")):
                    data = part.get_payload(decode=True)
                    if data:
                        return data.decode(part.get_content_charset() or "utf-8", "replace").strip()
            return ""
        data = msg.get_payload(decode=True)
        if data:
            return data.decode(msg.get_content_charset() or "utf-8", "replace").strip()
        return (msg.get_payload() or "").strip()