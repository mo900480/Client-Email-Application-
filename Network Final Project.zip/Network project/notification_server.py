import socket

# TCP notification server
def run_server(host="127.0.0.1", port=9999):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.listen()
        print(f"Server listening on {host}:{port}")
        while True:
            conn, addr = s.accept()
            with conn:
                msg = conn.recv(1024).decode("utf-8", "replace")
                if msg:
                    print(f"[{addr[0]}:{addr[1]}] {msg}")

if __name__ == "__main__":
    run_server()