import tkinter as tk
from tkinter import scrolledtext
from email_client import EmailClient
from plyer import notification

class EmailGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Email Client")
        self.root.geometry("1250x1000")
        self.root.configure(bg="#0d1117")
        self.root.minsize(1100, 850)

        self.vars = {
            "smtp_host": tk.StringVar(value="smtp.ethereal.email"),
            "smtp_port": tk.StringVar(value="587"),
            "imap_host": tk.StringVar(value="imap.ethereal.email"),
            "imap_port": tk.StringVar(value="993"),
            "email": tk.StringVar(),
            "password": tk.StringVar(),
            "recipient": tk.StringVar(),
            "subject": tk.StringVar()
        }

        self._build_ui()

    def _build_ui(self):
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure(0, weight=1)

        sidebar = tk.Frame(self.root, bg="#010409", width=240)
        sidebar.grid(row=0, column=0, sticky="ns")
        sidebar.grid_propagate(False)
        sidebar.columnconfigure(0, weight=1)

        tk.Label(sidebar, text="MAIL CLIENT", bg="#010409", fg="#f0f6fc",
                 font=("Segoe UI", 16, "bold")).grid(row=0, column=0, sticky="w", padx=25, pady=(30, 5))
        tk.Label(sidebar, text=" ", bg="#010409", fg="#484f58",
                 font=("Segoe UI", 9)).grid(row=1, column=0, sticky="w", padx=25, pady=(0, 40))

        status_frame = tk.Frame(sidebar, bg="#010409")
        status_frame.grid(row=2, column=0, sticky="ew", padx=25, pady=(0, 30))
        self.status_dot = tk.Canvas(status_frame, bg="#010409", highlightthickness=0, width=10, height=10)
        self.status_dot.pack(side="left")
        self.status_dot.create_oval(0, 0, 10, 10, fill="#3fb950", outline="")
        tk.Label(status_frame, text="System Ready", bg="#010409", fg="#3fb950",
                 font=("Segoe UI", 10, "bold")).pack(side="left", padx=(8, 0))

        menu_items = ["Dashboard", "SMTP Config", "IMAP Config", "Logs"]
        for i, item in enumerate(menu_items):
            lbl = tk.Label(sidebar, text=item, bg="#010409", fg="#8b949e",
                           font=("Segoe UI", 10), padx=25, pady=10, anchor="w")
            lbl.grid(row=3+i, column=0, sticky="ew")
            lbl.bind("<Enter>", lambda e, w=lbl: w.config(bg="#161b22", fg="#f0f6fc"))
            lbl.bind("<Leave>", lambda e, w=lbl: w.config(bg="#010409", fg="#8b949e"))

        tk.Label(sidebar, text="Team Members\n----------------\nAltaher Ahmed\nAmr Hesham\nAhmed Badr\nMohammed Saeed",
                 bg="#010409", fg="#58a6ff",
                 font=("Georgia", 15, "bold italic")).grid(row=99, column=0, sticky="s", padx=25, pady=20)

        main = tk.Frame(self.root, bg="#0d1117")
        main.grid(row=0, column=1, sticky="nsew", padx=35, pady=25)
        main.columnconfigure(0, weight=1)

        main.rowconfigure(0, weight=0)   # Header
        main.rowconfigure(1, weight=0)   # Cards  — fixed, no expansion
        main.rowconfigure(2, weight=0)   # Buttons — fixed
        main.rowconfigure(3, weight=1)   # Terminal — absorbs ALL remaining space

        # ── Header ──────────────────────────────────────────────────────────
        top = tk.Frame(main, bg="#0d1117")
        top.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        tk.Label(top, text="Dashboard", bg="#0d1117", fg="#f0f6fc",
                 font=("Segoe UI", 22, "bold")).pack(side="left")
        tk.Label(top, text="Send and receive emails securely", bg="#0d1117", fg="#8b949e",
                 font=("Segoe UI", 11)).pack(side="left", padx=(12, 0))

        # ── Cards ────────────────────────────────────────────────────────────
        cards = tk.Frame(main, bg="#0d1117")
        cards.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        cards.columnconfigure(0, weight=1)
        cards.columnconfigure(1, weight=1)

        # Server config card — reduced pady to shrink vertical footprint
        server = tk.Frame(cards, bg="#161b22", padx=20, pady=12)
        server.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        server.columnconfigure(0, weight=1)
        server.columnconfigure(1, weight=1)

        tk.Label(server, text="SERVER CONFIGURATION", bg="#161b22", fg="#58a6ff",
                 font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", columnspan=2, pady=(0, 10))

        self._entry(server, "SMTP Host", "smtp_host", 1, 0, 0)
        self._entry(server, "SMTP Port", "smtp_port", 1, 1, 0)
        self._entry(server, "IMAP Host", "imap_host", 3, 0, 0)
        self._entry(server, "IMAP Port", "imap_port", 3, 1, 0)
        self._entry(server, "Email Address", "email", 5, 0, 2)
        self._entry(server, "Password", "password", 7, 0, 2, show="*")

        # Compose card — body shrunk to 2 lines to save vertical space
        msg = tk.Frame(cards, bg="#161b22", padx=20, pady=12)
        msg.grid(row=0, column=1, sticky="nsew", padx=(12, 0))
        msg.columnconfigure(0, weight=1)
        msg.rowconfigure(6, weight=1)

        tk.Label(msg, text="COMPOSE MESSAGE", bg="#161b22", fg="#f0883e",
                 font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", pady=(0, 10))

        self._entry(msg, "Recipient", "recipient", 1, 0, 1)
        self._entry(msg, "Subject", "subject", 3, 0, 1)

        tk.Label(msg, text="Body", bg="#161b22", fg="#8b949e",
                 font=("Segoe UI", 9)).grid(row=5, column=0, sticky="w", pady=(6, 4))
        self.body = tk.Text(msg, height=2, wrap="word", font=("Segoe UI", 11),
                            bg="#0d1117", fg="#f0f6fc", insertbackground="#f0f6fc",
                            relief="flat", padx=12, pady=8)
        self.body.grid(row=6, column=0, sticky="nsew", pady=(0, 4))

        # ── Buttons ──────────────────────────────────────────────────────────
        actions = tk.Frame(main, bg="#0d1117")
        actions.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        actions.columnconfigure(0, weight=1)
        actions.columnconfigure(1, weight=1)

        self.btn_send = tk.Button(
            actions, text="Send Email", command=self.send_email,
            bg="#238636", fg="#ffffff", font=("Segoe UI", 12, "bold"),
            relief="flat", padx=40, pady=12, cursor="hand2"
        )
        self.btn_send.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self._hover(self.btn_send, "#238636", "#2ea043")

        self.btn_recv = tk.Button(
            actions, text="Receive Latest Email", command=self.receive_email,
            bg="#1f6feb", fg="#ffffff", font=("Segoe UI", 12, "bold"),
            relief="flat", padx=40, pady=12, cursor="hand2"
        )
        self.btn_recv.grid(row=0, column=1, sticky="ew", padx=(10, 0))
        self._hover(self.btn_recv, "#1f6feb", "#388bfd")

        # ── Output Console ───────────────────────────────────────────────────
        term = tk.Frame(main, bg="#010409", padx=2, pady=2)
        term.grid(row=3, column=0, sticky="nsew")
        term.columnconfigure(0, weight=1)
        term.rowconfigure(1, weight=1)

        term_header = tk.Frame(term, bg="#161b22", height=36)
        term_header.grid(row=0, column=0, sticky="ew")
        term_header.pack_propagate(False)
        tk.Label(term_header, text="Output Console", bg="#161b22", fg="#8b949e",
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=15)

        for color in ["#ff7b72", "#ffa657", "#3fb950"]:
            c = tk.Canvas(term_header, bg="#161b22", highlightthickness=0, width=10, height=10)
            c.pack(side="right", padx=(0, 10))
            c.create_oval(1, 1, 9, 9, fill=color, outline="")

        self.output = scrolledtext.ScrolledText(
            term, wrap="word", font=("JetBrains Mono", 10),
            bg="#010409", fg="#c9d1d9", insertbackground="#c9d1d9",
            relief="flat", padx=15, pady=12, bd=0,
            height=40
        )
        self.output.grid(row=1, column=0, sticky="nsew", padx=2, pady=2)

    def _entry(self, parent, label, key, row, col, colspan, show=None):
        tk.Label(parent, text=label, bg="#161b22", fg="#8b949e",
                 font=("Segoe UI", 9)).grid(row=row, column=col, sticky="w",
                 pady=(4, 2), columnspan=colspan if colspan else 1)
        ent = tk.Entry(parent, textvariable=self.vars[key], bg="#0d1117", fg="#f0f6fc",
                       insertbackground="#58a6ff", relief="flat", font=("Segoe UI", 11),
                       show=show if show else "", highlightthickness=1,
                       highlightbackground="#30363d", highlightcolor="#58a6ff")
        ent.grid(row=row+1, column=col, sticky="ew", padx=(0, 10) if col == 0 else (0, 0),
                 pady=(0, 4), ipady=6, columnspan=colspan if colspan else 1)
        if colspan:
            parent.columnconfigure(0, weight=1)

    def _hover(self, widget, normal, hover):
        widget.bind("<Enter>", lambda e: widget.config(bg=hover))
        widget.bind("<Leave>", lambda e: widget.config(bg=normal))

    def log(self, text):
        self.output.insert("end", text + "\n")
        self.output.see("end")
        self.output.update_idletasks()

    def client(self):
        return EmailClient(
            self.vars["smtp_host"].get().strip(),
            int(self.vars["smtp_port"].get().strip()),
            self.vars["imap_host"].get().strip(),
            int(self.vars["imap_port"].get().strip())
        )

    def _push(self, title, message):
        try:
            notification.notify(
                title=title,
                message=message,
                app_name="Email Client",
                timeout=6
            )
        except Exception as e:
            self.log(f"[PUSH ERROR] {e}")

    def send_email(self):
        c = self.client()
        ok, t, msg = c.send_email(
            self.vars["email"].get().strip(),
            self.vars["password"].get(),
            self.vars["recipient"].get().strip(),
            self.vars["subject"].get().strip(),
            self.body.get("1.0", "end").strip()
        )
        self.log(f"[SEND] {msg} | Time: {t:.4f}s")
        nok, nt = c.send_notification("Email Sent Successfully" if ok else "Email Sending Failed")
        self.log(f"[NOTIFY] {'Sent' if nok else 'Failed'} | Time: {nt:.4f}s")
        if ok:
            self._push("Email Client", "Email sent successfully")

    def receive_email(self):
        c = self.client()
        ok, t, subject, body, msg = c.receive_latest_email(
            self.vars["email"].get().strip(),
            self.vars["password"].get()
        )
        self.log(f"[RECEIVE] {msg} | Time: {t:.4f}s")
        if ok:
            self.log(f"Subject: {subject}")
            self.log(f"Body: {body[:500]}")
            nok, nt = c.send_notification("Email Received Successfully")
            self.log(f"[NOTIFY] {'Sent' if nok else 'Failed'} | Time: {nt:.4f}s")
            self._push("New Email Received", f"Subject: {subject}")
        else:
            nok, nt = c.send_notification("Email Receiving Failed")
            self.log(f"[NOTIFY] {'Sent' if nok else 'Failed'} | Time: {nt:.4f}s")

if __name__ == "__main__":
    root = tk.Tk()
    EmailGUI(root)
    root.mainloop()